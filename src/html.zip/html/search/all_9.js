var searchData=
[
  ['write',['Write',['../gui_8py.html#acd2668ca2fd16b5a36d8e7cb572bdb9c',1,'gui']]]
];
