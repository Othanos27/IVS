var searchData=
[
  ['oper',['oper',['../gui_8py.html#a79fa5cba7514a59524f1d9e9bbdc61ac',1,'gui']]]
];
