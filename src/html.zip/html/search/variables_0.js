var searchData=
[
  ['asign',['Asign',['../gui_8py.html#a20e017477ff732dfd1bf0d053900bf34',1,'gui']]]
];
