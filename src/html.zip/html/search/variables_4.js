var searchData=
[
  ['width',['width',['../gui_8py.html#a8f8e889a7e2d0da352da25a346afdbb7',1,'gui']]]
];
