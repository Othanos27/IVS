var searchData=
[
  ['bsign',['Bsign',['../gui_8py.html#accc3757127da1ab93c373401502726c1',1,'gui']]]
];
